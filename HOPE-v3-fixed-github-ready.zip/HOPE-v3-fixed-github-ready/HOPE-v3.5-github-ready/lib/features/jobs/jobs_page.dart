import 'package:flutter/material.dart';
import '../../core/network/api_client.dart';
import '../../core/ui/components.dart';
import '../../theme/app_theme.dart';
import '../marketplace/job_detail_page.dart';

class JobsPage extends StatefulWidget {
  const JobsPage({super.key, required this.api});
  final ApiClient api;
  @override State<JobsPage> createState() => _JobsPageState();
}

class _JobsPageState extends State<JobsPage> {
  late Future<dynamic> future;
  String query = '';
  @override void initState() { super.initState(); future = widget.api.request('GET', '/jobs'); }
  Future<void> refresh() async { setState(() => future = widget.api.request('GET', '/jobs')); await future.catchError((_) => null); }

  @override
  Widget build(BuildContext context) => Directionality(textDirection: TextDirection.rtl, child: FutureBuilder<dynamic>(
    future: future,
    builder: (context, snap) {
      final raw = snap.data;
      final all = raw is List ? raw : (raw is Map && raw['data'] is List ? raw['data'] as List : const <dynamic>[]);
      final items = all.where((item) {
        if (query.trim().isEmpty || item is! Map) return true;
        final q = query.trim().toLowerCase();
        return '${item['title'] ?? ''} ${item['description'] ?? ''} ${item['city'] ?? ''}'.toLowerCase().contains(q);
      }).toList();
      return RefreshIndicator(onRefresh: refresh, child: CustomScrollView(physics: const AlwaysScrollableScrollPhysics(), slivers: [
        SliverPadding(padding: const EdgeInsets.fromLTRB(20, 17, 20, 14), sliver: SliverToBoxAdapter(child: AnimatedEntrance(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('کشف کار', style: Theme.of(context).textTheme.displaySmall), const SizedBox(height: 5), Text('فرصتی را پیدا کن که ارزش وقتت را داشته باشد.', style: Theme.of(context).textTheme.bodyLarge)])), const HopeIconTile(Icons.explore_rounded, size: 50, filled: true)]),
          const SizedBox(height: 20), SearchField(onChanged: (v) => setState(() => query = v), hint: 'عنوان، شهر یا توضیحات...'),
          const SizedBox(height: 12), Row(children: [StatusPill('${items.length} فرصت', color: AppColors.primary, icon: Icons.bolt_rounded), const SizedBox(width: 7), StatusPill('به‌روز', color: AppColors.success, icon: Icons.refresh_rounded)]),
        ]))),
        if (snap.connectionState == ConnectionState.waiting)
          const SliverFillRemaining(hasScrollBody: false, child: Center(child: CircularProgressIndicator()))
        else if (snap.hasError)
          const SliverFillRemaining(hasScrollBody: false, child: EmptyState(icon: Icons.cloud_off_rounded, title: 'اتصال برقرار نشد', message: 'برای دریافت فرصت‌های کاری دوباره تلاش کن.'))
        else if (items.isEmpty)
          const SliverFillRemaining(hasScrollBody: false, child: EmptyState(icon: Icons.search_off_rounded, title: 'چیزی پیدا نشد', message: 'عبارت جست‌وجو را تغییر بده یا دوباره امتحان کن.'))
        else
          SliverPadding(padding: const EdgeInsets.fromLTRB(20, 0, 20, 122), sliver: SliverList.builder(itemCount: items.length, itemBuilder: (context, i) {
            final job = items[i] is Map ? Map<String, dynamic>.from(items[i] as Map) : <String, dynamic>{};
            return Padding(padding: const EdgeInsets.only(bottom: 13), child: _JobCard(api: widget.api, job: job));
          })),
      ]));
    },
  ));
}

class _JobCard extends StatelessWidget {
  const _JobCard({required this.api, required this.job});
  final ApiClient api; final Map<String, dynamic> job;
  @override
  Widget build(BuildContext context) {
    final title = '${job['title'] ?? 'بدون عنوان'}'; final desc = '${job['description'] ?? ''}'; final city = job['city']; final status = '${job['status'] ?? 'PUBLISHED'}';
    final min = job['budgetMin']?.toString() ?? '—'; final max = job['budgetMax']?.toString() ?? '—';
    return PressableScale(onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => JobDetailPage(api: api, job: job))), semanticLabel: 'جزئیات $title', child: HopeSurface(highlight: true, child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        const HopeIconTile(Icons.work_rounded, size: 48, color: AppColors.primary), const SizedBox(width: 12),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.titleMedium), const SizedBox(height: 4), Text(city?.toString().trim().isNotEmpty == true ? '$city' : 'فرصت آنلاین', style: Theme.of(context).textTheme.bodyMedium)])),
        const Icon(Icons.arrow_back_ios_new_rounded, size: 15),
      ]),
      if (desc.trim().isNotEmpty) ...[const SizedBox(height: 13), Text(desc, maxLines: 2, overflow: TextOverflow.ellipsis, style: Theme.of(context).textTheme.bodyMedium)],
      const SizedBox(height: 15), Wrap(spacing: 7, runSpacing: 7, children: [
        StatusPill(status == 'PUBLISHED' ? 'منتشر شده' : status, color: AppColors.success, icon: Icons.check_circle_outline_rounded),
        StatusPill('$min تا $max', icon: Icons.payments_outlined),
        if (job['duration'] != null) StatusPill('${job['duration']} ساعت', color: AppColors.secondary, icon: Icons.schedule_rounded),
      ]),
    ]))));
  }
}
